
# ~~~~~~IMPLEMENTATION DE bag-of-words avec SIFT, K-MEANS et SVM~~~~~~~#



## Commande pour la phase d'apprentissage
```
python findFeatures.py -t dataset/train/
```

## Commande pour la phase de test de classification
* Test sur l'ensemble de la base de test
```
python getClass.py -t dataset/test --visualize
```
Le paramettre `--visualize`  permet des d'afficher les images de la base avec leur etiquette 

* Test sur une image
```
python getClass.py -i dataset/test/aeroplane/obj1__90.png --visualize
```

